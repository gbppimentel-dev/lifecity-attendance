// Change ID: LC-CAMERA-STARTUP-v2
// Change ID: LC-MOBILE-CAMERA-v1
// Change ID: LC-P08L-v1
// Change ID: LC-P08E-v1
// Change ID: LC-P08D-v1
// Change ID: LC-UI-COPY-v2
import { uiMessage } from '../lib/uiText'
import { type FormEvent, useEffect, useRef, useState } from 'react'
import { ChevronDown, CheckCircle2, Expand, Minimize, ScanLine, Search, SwitchCamera, TriangleAlert, X } from 'lucide-react'
import { Html5Qrcode } from 'html5-qrcode'
import { supabase } from '../lib/supabase'

type AttendanceEvent = {
  id: string
  name: string
  starts_at: string
}

type ScanResult = {
  type: 'success' | 'duplicate' | 'error'
  message: string
  memberName?: string
  time?: string
}

type Props = {
  event: AttendanceEvent | null
}

type SearchMember = {
  id: string
  first_name: string
  last_name: string
  member_number: string
  email: string | null
  mobile: string | null
  status: string
}

type CameraDevice = {
  id: string
  label: string
}

type RecentCheckIn = {
  memberName: string
  time: string
}

/*
  This shared queue prevents React Strict Mode from starting a second
  camera instance before the first one has completely stopped.
*/
let scannerShutdown = Promise.resolve()

export default function AttendanceScanner({ event }: Props) {
  const [manualOpen,setManualOpen]=useState(false)
  const [processing, setProcessing] = useState(false)
  const attemptSequence = useRef(0)
  const releaseTimer = useRef<number | null>(null)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [matchedMembers, setMatchedMembers] = useState<SearchMember[]>([])
  const [matchTotal, setMatchTotal] = useState(0)
  const [searchBusy, setSearchBusy] = useState(false)
  const [searchRetry, setSearchRetry] = useState(0)
  const [finishedSearchKey, setFinishedSearchKey] = useState('')
  const [selectedMemberEventId, setSelectedMemberEventId] = useState('')
  const currentEventId = useRef(event?.id)
  currentEventId.current = event?.id
  const mounted = useRef(true)
  useEffect(() => {mounted.current=true;return () => {mounted.current=false;attemptSequence.current++;if(releaseTimer.current)clearTimeout(releaseTimer.current)}},[])
  const [memberSearch, setMemberSearch] = useState('')
  const [selectedMember, setSelectedMember] = useState<SearchMember | null>(null)
  const [memberLoadError, setMemberLoadError] = useState('')
  const [cameraError, setCameraError] = useState('')
  const [cameras, setCameras] = useState<CameraDevice[]>([])
  const [cameraId, setCameraId] = useState('')
  const [facingMode,setFacingMode]=useState<'user'|'environment'>('environment')
  const [cameraState,setCameraState]=useState<'starting'|'ready'|'error'>('starting')
  const [cameraRetry,setCameraRetry]=useState(0)
  const activeDevice=useRef('')
  const activeFacing=useRef<'user'|'environment'>('environment')
  const [recentCheckIns, setRecentCheckIns] = useState<RecentCheckIn[]>([])
  const [isKioskMode, setIsKioskMode] = useState(false)
  const kioskButtonRef = useRef<HTMLButtonElement>(null)
  const nativeKiosk = useRef(false)
  const processingRef = useRef(false)
  const scannerRef = useRef<Html5Qrcode | null>(null)
  const scannerLayoutRef = useRef<HTMLElement | null>(null)

  const searchKey = JSON.stringify([event?.id,memberSearch.trim(),searchRetry])
  const currentSearchKey = useRef(searchKey)
  currentSearchKey.current = searchKey
  const waitingForSearch = searchBusy || finishedSearchKey!==searchKey

  function notifySuccessfulCheckIn() {
    if ('vibrate' in navigator) {
      navigator.vibrate?.([70, 45, 90])
    }

    const AudioContextConstructor = window.AudioContext
      ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext

    if (!AudioContextConstructor) return

    try {
      const audioContext = new AudioContextConstructor()
      const oscillator = audioContext.createOscillator()
      const gain = audioContext.createGain()

      oscillator.type = 'sine'
      oscillator.frequency.setValueAtTime(880, audioContext.currentTime)
      gain.gain.setValueAtTime(0.0001, audioContext.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.12, audioContext.currentTime + 0.015)
      gain.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 0.14)

      oscillator.connect(gain)
      gain.connect(audioContext.destination)
      oscillator.start()
      oscillator.stop(audioContext.currentTime + 0.15)
      oscillator.addEventListener('ended', () => void audioContext.close())
    } catch {
      // Audio feedback is an enhancement; a successful check-in must still continue.
    }
  }

  function addRecentCheckIn(memberName: string, time: string) {
    setRecentCheckIns((current) => [
      { memberName, time },
      ...current,
    ].slice(0, 2))
  }

  function attemptIsCurrent(attempt: number, serviceId: string) {
    return mounted.current && attemptSequence.current===attempt && currentEventId.current===serviceId
  }

  function startAttempt() {
    if(!event || !mounted.current || currentEventId.current!==event.id || processingRef.current)return null
    const attempt=++attemptSequence.current
    processingRef.current=true
    setProcessing(true)
    setResult(null)
    return {attempt,serviceId:event.id}
  }

  function finishAttempt(attempt: number, serviceId: string) {
    if(!attemptIsCurrent(attempt,serviceId))return
    setProcessing(false)
    // Keep a short cooldown so a QR held in the frame is not immediately read again.
    releaseTimer.current=window.setTimeout(()=>{
      if(attemptIsCurrent(attempt,serviceId))processingRef.current=false
    },1800)
  }

  async function recordMemberAttendance(member: Pick<SearchMember, 'id' | 'first_name' | 'last_name' | 'status'>, attempt: number, serviceId: string) {
    if(!attemptIsCurrent(attempt,serviceId))return
    const memberName=`${member.first_name} ${member.last_name}`
    if(member.status!=='active'){
      setResult({type:'error',memberName,message:'This member is inactive.'})
      return
    }
    const {error}=await supabase.from('attendance').insert({member_id:member.id,event_id:serviceId})
    if(!attemptIsCurrent(attempt,serviceId))return
    if(error?.code==='23505'){
      setResult({type:'duplicate',memberName,message:'Already checked in for this service.'})
    }else if(error){
      setResult({type:'error',memberName,message:'Check-in could not be confirmed. Please try again. Existing check-ins will not be duplicated.'})
    }else{
      const checkInTime=new Intl.DateTimeFormat('en-PH',{timeZone:'Asia/Manila',hour:'numeric',minute:'2-digit',second:'2-digit'}).format(new Date())
      notifySuccessfulCheckIn()
      addRecentCheckIn(memberName,checkInTime)
      setResult({type:'success',memberName,message:'Attendance recorded successfully.',time:checkInTime})
    }
  }

  async function recordAttendance(rawCode: string) {
    const started=startAttempt()
    if(!started)return
    const {attempt,serviceId}=started
    try{
      const token=rawCode.trim().replace(/^att:/,'')
      if(!token){setResult({type:'error',message:'This QR code is not valid.'});return}
      const {data:member,error}=await supabase.from('members')
        .select('id, first_name, last_name, status').eq('qr_token',token).maybeSingle()
      if(!attemptIsCurrent(attempt,serviceId))return
      if(error)throw error
      if(!member){setResult({type:'error',message:'No member was found for this QR code.'});return}
      await recordMemberAttendance(member,attempt,serviceId)
    }catch{
      if(attemptIsCurrent(attempt,serviceId))setResult({type:'error',message:'Check-in could not be confirmed. Please scan again. Existing check-ins will not be duplicated.'})
    }finally{
      finishAttempt(attempt,serviceId)
    }
  }

  useEffect(() => {
    let disposed=false
    const key=searchKey
    const term=memberSearch.trim()
    const isCurrent=() => !disposed && mounted.current && currentSearchKey.current===key
    setMemberLoadError('')
    setMatchedMembers([])
    setMatchTotal(0)
    if(!event || !term || selectedMember) {
      setSearchBusy(false);setFinishedSearchKey(key)
      return () => {disposed=true}
    }
    setSearchBusy(true)
    const timer=window.setTimeout(async () => {
      try {
        const {data,error}=await supabase.rpc('lc_scanner_member_search',{p_search:term})
        if(!isCurrent())return
        if(error)throw error
        if(!data || !Array.isArray(data.rows) || typeof data.total!=='number')throw new Error('Invalid member search response')
        setMatchedMembers(data.rows as SearchMember[])
        setMatchTotal(data.total)
      } catch {
        if(isCurrent())setMemberLoadError('Member search is not available right now. Please try again.')
      } finally {
        if(isCurrent()){setSearchBusy(false);setFinishedSearchKey(key)}
      }
    },300)
    return () => {disposed=true;window.clearTimeout(timer)}
  },[searchKey,selectedMember])

  useEffect(() => {
    attemptSequence.current++
    if(releaseTimer.current)clearTimeout(releaseTimer.current)
    processingRef.current=false
    setProcessing(false)
    setResult(null)
    setRecentCheckIns([])
    setSelectedMember(null)
    setSelectedMemberEventId('')
    setMemberSearch('')
  }, [event?.id])

  useEffect(() => {
    if(!event)return
    let disposed=false
    let scanner:Html5Qrcode|null=null
    let track:MediaStreamTrack|null=null
    setCameraState('starting');setCameraError('')
    async function startCamera(){
      await scannerShutdown
      if(disposed)return
      const reader=document.getElementById('attendance-reader')
      if(!reader)return
      reader.replaceChildren()
      if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
        setCameraState('error')
        setCameraError(!window.isSecureContext
          ? 'Camera access requires HTTPS or localhost. Open this app using a secure URL, then retry.'
          : 'Camera access is not available in this browser. Open the app in a browser with camera support.')
        return
      }
      try{
        scanner=new Html5Qrcode('attendance-reader',{verbose:false})
        await scanner.start(
          cameraId?{deviceId:{exact:cameraId}}:{facingMode},
          {fps:10,qrbox:(width,height)=>{const size=Math.min(250,Math.floor(Math.min(width,height)*.8));return {width:size,height:size}},aspectRatio:1},
          text=>{if(!disposed)void recordAttendance(text)},()=>{},
        )
      }catch(error){
        if(!disposed){
          const detail = error instanceof Error ? `${error.name}: ${error.message}` : String(error)
          let message = 'Could not start this camera. Choose Retry Camera or Switch Camera. If it still fails, check the browser console for the camera error.'
          if (/NotAllowedError|PermissionDeniedError|permission denied/i.test(detail)) {
            message = 'Camera permission was denied. Allow camera access for this site in your browser and system settings, then choose Retry Camera.'
          } else if (/NotFoundError|DevicesNotFoundError/i.test(detail)) {
            message = 'No camera was found. Connect or enable a camera, then choose Retry Camera.'
          } else if (/NotReadableError|TrackStartError|could not start video source/i.test(detail)) {
            message = 'The camera could not be opened. Close other apps or browser tabs using it, then choose Retry Camera.'
          } else if (/OverconstrainedError|ConstraintNotSatisfiedError/i.test(detail)) {
            message = 'The selected camera or camera settings are unavailable. Choose Switch Camera to try another camera.'
          }
          console.error('LifeCity camera startup failed:', error)
          setCameraState('error');setCameraError(message)
        }
        return
      }
      if(disposed)return
      scannerRef.current=scanner
      // Mirror only the desktop preview. Canvas decoding still reads the original
      // video pixels, and mobile front/rear camera presentation stays unchanged.
      const preview=reader.querySelector('video')
      const mobileNavigator=navigator as Navigator & {userAgentData?:{mobile?:boolean}}
      const isMobile=mobileNavigator.userAgentData?.mobile===true
        || /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)
        || (navigator.platform==='MacIntel' && navigator.maxTouchPoints>1)
      if(preview && !isMobile)preview.style.setProperty('transform','scaleX(-1)')
      setCameraState('ready');setCameraError('')
      // Optional metadata must never turn a successful start into an access error.
      try{
        const video=reader.querySelector('video')
        const stream=video?.srcObject as MediaStream|null
        track=stream?.getVideoTracks?.()[0]??null
        const settings=track?.getSettings?.()??scanner.getRunningTrackSettings()
        activeDevice.current=settings.deviceId??cameraId
        activeFacing.current=settings.facingMode==='user'?'user':settings.facingMode==='environment'?'environment':facingMode
      }catch{activeDevice.current=cameraId;activeFacing.current=facingMode}
      // Enumerate after permission, without requesting a second camera stream.
      try{
        void navigator.mediaDevices.enumerateDevices().then(devices=>{
          if(!disposed)setCameras(devices.filter(device=>device.kind==='videoinput'&&device.deviceId).map(device=>({id:device.deviceId,label:device.label})))
        }).catch(()=>{if(!disposed)setCameras([])})
      }catch{if(!disposed)setCameras([])}
    }
    const startup=startCamera()
    return()=>{
      disposed=true
      scannerShutdown=scannerShutdown.then(async()=>{
        await startup
        if(!scanner)return
        if(scannerRef.current===scanner){scannerRef.current=null}
        try{await scanner.stop()}catch{track?.stop()}
        try{scanner.clear()}catch{/* Reader may already be removed. */}
      })
    }
  },[event?.id,cameraId,facingMode,cameraRetry,isKioskMode])

  useEffect(() => {
    function updateKioskMode() {
      const active = document.fullscreenElement === scannerLayoutRef.current
      if (nativeKiosk.current && !active) setIsKioskMode(false)
      nativeKiosk.current = active
    }
    document.addEventListener('fullscreenchange', updateKioskMode)
    return () => document.removeEventListener('fullscreenchange', updateKioskMode)
  }, [])

  useEffect(() => {
    if (!isKioskMode) return
    const previous = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    // Also isolate the viewport-filling fallback when native fullscreen is unavailable.
    const siblings: {element:HTMLElement; inert:boolean}[] = []
    let branch: HTMLElement | null = scannerLayoutRef.current
    while (branch?.parentElement && branch !== document.body) {
      for (const sibling of Array.from(branch.parentElement.children)) {
        if (sibling !== branch && sibling instanceof HTMLElement) {
          siblings.push({element:sibling,inert:sibling.inert}); sibling.inert=true
        }
      }
      branch=branch.parentElement
    }
    function escape(e:KeyboardEvent) { if(e.key==='Escape') setIsKioskMode(false) }
    window.addEventListener('keydown',escape)
    kioskButtonRef.current?.focus({preventScroll:true})
    return () => {
      document.body.style.overflow=previous
      siblings.forEach(({element,inert})=>{element.inert=inert})
      window.removeEventListener('keydown',escape)
      kioskButtonRef.current?.focus({preventScroll:true})
    }
  },[isKioskMode])

  useEffect(()=>{if(!event) setIsKioskMode(false)},[event])

  function switchCamera() {
    if(cameraState==='starting')return
    const nextFacing=activeFacing.current==='environment'?'user':'environment'
    const opposite=cameras.find(camera=>camera.id!==activeDevice.current && (nextFacing==='user'?/front|user|facetime/i:/back|rear|environment/i).test(camera.label))
    const currentIndex=cameras.findIndex(camera=>camera.id===activeDevice.current)
    const next=opposite??(cameras.length>1?cameras[(currentIndex+1)%cameras.length]:undefined)
    setCameraState('starting');setCameraError('')
    setCameraId(next?.id??'')
    setFacingMode(nextFacing)
    setCameraRetry(value=>value+1)
  }

  async function toggleKioskMode() {
    if (isKioskMode) {
      setIsKioskMode(false)
      if(document.fullscreenElement===scannerLayoutRef.current) {
        try {await document.exitFullscreen()} catch { /* The viewport layout still exits. */ }
      }
      return
    }
    setIsKioskMode(true)
    try { await scannerLayoutRef.current?.requestFullscreen?.() }
    catch { /* Keep the accessible viewport-filling kiosk if fullscreen is blocked. */ }
  }

  function submitMemberSearch(formEvent: FormEvent<HTMLFormElement>) {
    formEvent.preventDefault()
    if(!selectedMember || !event || selectedMemberEventId!==event.id)return
    const started=startAttempt()
    if(!started)return
    const {attempt,serviceId}=started
    const memberId=selectedMember.id
    setSelectedMember(null)
    setSelectedMemberEventId('')
    setMemberSearch('')
    void (async()=>{
      try{
        const {data:member,error}=await supabase.from('members')
          .select('id, first_name, last_name, status').eq('id',memberId).maybeSingle()
        if(!attemptIsCurrent(attempt,serviceId))return
        if(error)throw error
        if(!member){setResult({type:'error',message:'This member is no longer available. Search again before checking in.'});return}
        await recordMemberAttendance(member,attempt,serviceId)
      }catch{
        if(attemptIsCurrent(attempt,serviceId))setResult({type:'error',message:'Check-in could not be confirmed. Search for this member and try again. Existing check-ins will not be duplicated.'})
      }finally{
        finishAttempt(attempt,serviceId)
      }
    })()
  }

  if (!event) {
    return (
      <section className="scanner-empty lc-scanner-idle">
        <div className="lc-scanner-idle-art" aria-hidden="true"><ScanLine size={36}/><span/></div>
        <h2>Select an Event First</h2>
        <p>Choose a service or gathering above before opening the scanner.</p>
      </section>
    )
  }

  return (
    <section ref={scannerLayoutRef} className={`scanner-layout${isKioskMode ? ' is-kiosk-mode' : ''}`}>
      <div className="scanner-camera-heading">
        <div>
          <p className="card-kicker">{isKioskMode ? 'LifeCity · Self check-in' : 'Camera Scanner'}</p>
          <h2>Scan Member QR</h2>
          <p>Hold the QR code inside the frame to check in automatically.</p>
        </div>
        <div className="scanner-camera-actions">
          <button
            type="button"
            ref={kioskButtonRef}
            aria-pressed={isKioskMode}
            className={`scanner-camera-switch lc-kiosk-toggle${isKioskMode ? ' is-active' : ''}`}
            onClick={() => void toggleKioskMode()}
            title={isKioskMode ? 'Exit Kiosk Mode' : 'Open Kiosk Mode'}
          >
            {isKioskMode ? <Minimize size={16} /> : <Expand size={16} />}
            {isKioskMode ? 'Exit Kiosk' : 'Kiosk Mode'}
          </button>
          {(
            <button
              type="button"
              className="scanner-camera-switch lc-camera-icon"
              aria-label="Switch camera"
              onClick={switchCamera}
              disabled={cameraState==='starting'}
              title="Switch Camera"
            >
              <SwitchCamera size={16} />
            </button>
          )}
          {cameraState==='error' && <button type="button" className="scanner-camera-switch" onClick={()=>{setCameraState('starting');setCameraRetry(value=>value+1)}}>Retry Camera</button>}
          <span className={cameraState==='ready'?'scanner-ready-status':'manual-member-search-help'} role="status">
            {cameraState==='ready' && <i/>}{cameraState==='ready'?'Ready':cameraState==='starting'?'Starting Camera…':'Camera Unavailable'}
          </span>
        </div>
      </div>

      <div className="lc-scanner-workspace">
      <div className="scanner-camera-stage">
        <div id="attendance-reader" className="scanner-reader" />
      </div>

      <aside className="lc-scanner-feedback" aria-label="Check-in feedback">
      {isKioskMode && <div className="lc-kiosk-service"><p className="card-kicker">You’re checking in to</p><h2 title={event.name}>{event.name}</h2><p>{new Date(event.starts_at).toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}</p></div>}
      {isKioskMode && !result && !processing && !cameraError && <div className="lc-kiosk-welcome"><ScanLine size={44} aria-hidden="true"/><h2>Ready when you are.</h2><p>Hold your member QR code in the camera frame. Your confirmation will appear here.</p></div>}
      {recentCheckIns.length > 0 && (
        <div className="scanner-recent-checkins" aria-live="polite">
          <span>Last Checked in</span>
          <div>
            {recentCheckIns.map((checkIn, index) => (
              <p key={`${checkIn.memberName}-${checkIn.time}-${index}`}>
                <strong>{checkIn.memberName}</strong>
                <small>{checkIn.time}</small>
              </p>
            ))}
          </div>
        </div>
      )}

      {cameraError && (
        <div className="scan-result error">
          <TriangleAlert size={28} />
          <p>{uiMessage(cameraError)}</p>
        </div>
      )}

      {processing && <p className="manual-member-search-help" role="status" aria-live="polite">Checking in… Please wait.</p>}

      {result && (
        <div className={`scan-result ${result.type}`} role="status" aria-live="polite">
          {result.type === 'success' ? (
            <CheckCircle2 size={28} />
          ) : (
            <TriangleAlert size={28} />
          )}

          <div>
            {result.memberName && <strong>{result.memberName}</strong>}
            <p>{uiMessage(result.message)}</p>
            {result.time && <span>{result.time}</span>}
          </div>
        </div>
      )}

      {isKioskMode && <p className="lc-kiosk-tip">Need help? Exit kiosk to search for a member.</p>}
      </aside>
      </div>
      <section className={`manual-checkin-card${manualOpen?' lcs-manual-open':''}`} hidden={isKioskMode}>
        <button type="button" className="lcs-manual-toggle" aria-expanded={manualOpen} aria-controls="lcs-manual-form" onClick={()=>setManualOpen(value=>!value)}><Search size={16}/><span>Find a Member Manually</span><ChevronDown size={16}/></button>
        <div className="manual-checkin-heading">
          <p>Manual Check-In</p>
          <span>Use member search only when a QR code cannot be scanned.</span>
        </div>

        <form id="lcs-manual-form" className="manual-member-search" onSubmit={submitMemberSearch}>
          <div className="manual-member-search-input">
            <Search size={18} />
            <input
              value={memberSearch}
              onChange={(event) => {
                setMemberSearch(event.target.value)
                setSelectedMember(null)
              }}
              placeholder="Search Members"
              aria-label="Search for a Member to Check in"
            />
          </div>

          <button className="secondary-button manual-checkin-button" disabled={!selectedMember || selectedMemberEventId!==event.id || processing}>
            {processing ? 'Checking In…' : 'Check In'}
          </button>

          <p className="manual-member-search-help">
            Search by first name, last name, full name, mobile number, member ID, or email.
          </p>

          {memberLoadError && !waitingForSearch && !selectedMember && <div role="alert"><p className="error-message">{memberLoadError}</p><button type="button" className="secondary-button" onClick={()=>setSearchRetry(value=>value+1)}>Try Again</button></div>}

          {selectedMember && (
            <div className="manual-member-selected">
              <div>
                <strong>{selectedMember.first_name} {selectedMember.last_name}</strong>
                <span>{selectedMember.member_number}{selectedMember.email ? ` · ${selectedMember.email}` : ''}</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedMember(null)
                  setMemberSearch('')
                }}
                aria-label="Clear Selected Member"
              >
                <X size={16} />
              </button>
            </div>
          )}

          {!selectedMember && memberSearch.trim() && (
            <div className="manual-member-results">
              {waitingForSearch ? (
                <p role="status">Searching members…</p>
              ) : memberLoadError ? null : matchedMembers.length === 0 ? (
                <p role="status">No active members found.</p>
              ) : (
                matchedMembers.map((member) => (
                  <button
                    type="button"
                    key={member.id}
                    onClick={() => {
                      setSelectedMember(member)
                      setSelectedMemberEventId(event.id)
                      setMemberSearch(`${member.first_name} ${member.last_name}`)
                    }}
                  >
                    <strong>{member.first_name} {member.last_name}</strong>
                    <span>{member.member_number}{member.email ? ` · ${member.email}` : ''}</span>
                  </button>
                ))
              )}
              {!waitingForSearch && !memberLoadError && matchTotal>matchedMembers.length && <p className="manual-member-search-help">Showing {matchedMembers.length} of {matchTotal} matches. Add a surname, member ID, email, or mobile number to narrow your search.</p>}
            </div>
          )}
        </form>
      </section>
    </section>
  )
}
